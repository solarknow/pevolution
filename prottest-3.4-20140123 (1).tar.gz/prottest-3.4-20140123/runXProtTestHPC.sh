java -cp prottest-3.4.jar es.uvigo.darwin.xprottest.XProtTestApp
